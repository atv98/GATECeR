#define t4DWordArray  word *
#define t4DByteArray  char *
//#define t4DSector     unsigned char *
